/**
 * 
 */
/**
 * @author s.zeghlii
 *
 */
module CalculateAge {
	requires java.desktop;
}